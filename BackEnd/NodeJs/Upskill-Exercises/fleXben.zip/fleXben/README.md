Below are the contents of `.env` file.
`````````````
# NODE APP ENVIRONMENT
PORT=5000

# DATABSE CONNECTION
DB_HOST=BMMBQG3
DB_USER=sa
DB_PASSWORD=mysqlserver
DB_NAME=flexben

# JWT
SECRET=")x2f-l-opsnd)w!!z2m7ykvony99pt@6@6m+=q2uk3%w8*7$ow-villanda"
ALGORITHM="HS256"
ISSUER="FLEXBEN"
EXPIRY="1h"
`````````````